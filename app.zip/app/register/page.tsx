"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function RegisterPage() {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [error, setError] = useState("");
  const router = useRouter();

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(""); // เคลียร์แจ้งเตือนเก่า

    // 1. เช็กก่อนว่ารหัสผ่าน 2 ช่องตรงกันไหม
    if (password !== confirmPassword) {
      setError("รหัสผ่านและการยืนยันรหัสผ่านไม่ตรงกัน");
      return;
    }

    try {
      // 2. ยิงข้อมูลไปหา Spring Boot
      const response = await fetch("http://localhost:8080/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          firstName: firstName,
          lastName: lastName,
          email: email,
          password: password,
        }),
      });

      if (response.ok) {
        alert("สมัครสมาชิกสำเร็จ! กรุณาเข้าสู่ระบบ");
        router.push("/login"); // เด้งไปหน้า Login ให้ผู้ใช้เข้าระบบ
      } else {
        // ถ้ายิงไปแล้วติด Error 400 (เช่น อีเมลซ้ำ ที่เราทำดักไว้ใน Backend)
        const errorMsg = await response.text();
        setError(errorMsg || "ไม่สามารถสมัครสมาชิกได้ กรุณาลองใหม่อีกครั้ง");
      }
    } catch (err) {
      setError("ไม่สามารถเชื่อมต่อกับเซิร์ฟเวอร์ได้ กรุณาตรวจสอบ Spring Boot");
    }
  };

  return (
    <main className="min-h-screen flex items-center justify-center bg-gray-50 text-gray-900 py-12">
      <div className="bg-white p-10 md:p-14 shadow-sm border border-gray-100 w-full max-w-lg mt-16">
        {/* หัวข้อ */}
        <div className="text-center mb-10">
          <h1 className="text-3xl font-light tracking-widest mb-4">
            CREATE ACCOUNT
          </h1>
          <div className="w-10 h-[1px] bg-black mx-auto"></div>
        </div>

        {/* กล่องแสดงข้อความ Error สีแดง */}
        {error && (
          <div className="mb-6 p-3 text-sm text-red-600 bg-red-50 border border-red-100 text-center">
            {error}
          </div>
        )}

        {/* ฟอร์มกรอกข้อมูล */}
        <form onSubmit={handleRegister} className="space-y-6">
          {/* แถวนี้แบ่งครึ่งซ้ายขวา (ชื่อ - นามสกุล) */}
          <div className="flex gap-4">
            <div className="w-1/2">
              <label className="block text-xs uppercase tracking-widest text-gray-400 mb-2">
                First Name
              </label>
              <input
                type="text"
                className="w-full border-b border-gray-300 py-2 focus:outline-none focus:border-black transition-colors bg-transparent"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                required
              />
            </div>
            <div className="w-1/2">
              <label className="block text-xs uppercase tracking-widest text-gray-400 mb-2">
                Last Name
              </label>
              <input
                type="text"
                className="w-full border-b border-gray-300 py-2 focus:outline-none focus:border-black transition-colors bg-transparent"
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs uppercase tracking-widest text-gray-400 mb-2">
              Email
            </label>
            <input
              type="email"
              className="w-full border-b border-gray-300 py-2 focus:outline-none focus:border-black transition-colors bg-transparent"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div>
            <label className="block text-xs uppercase tracking-widest text-gray-400 mb-2">
              Password
            </label>
            <input
              type="password"
              className="w-full border-b border-gray-300 py-2 focus:outline-none focus:border-black transition-colors bg-transparent"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              minLength={3}
            />
          </div>

          <div>
            <label className="block text-xs uppercase tracking-widest text-gray-400 mb-2">
              Confirm Password
            </label>
            <input
              type="password"
              className="w-full border-b border-gray-300 py-2 focus:outline-none focus:border-black transition-colors bg-transparent"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              required
            />
          </div>

          <button
            type="submit"
            className="w-full bg-black text-white py-4 mt-8 uppercase tracking-widest text-sm hover:bg-gray-800 transition duration-300"
          >
            Register
          </button>
        </form>

        {/* ลิงก์กลับไปหน้า Login */}
        <div className="mt-8 text-center text-sm text-gray-500 font-light">
          <span>Already have an account? </span>
          <Link
            className="text-black border-b border-black pb-1 hover:text-gray-600 transition ml-2"
            href="/login"
          >
            Sign In
          </Link>
        </div>
      </div>
    </main>
  );
}
